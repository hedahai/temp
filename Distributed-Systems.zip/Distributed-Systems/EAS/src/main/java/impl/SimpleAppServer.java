package impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import protocol.AppServer;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SimpleAppServer extends AppProcess implements AppServer {

    private static Logger logger = LogManager.getLogger(SimpleAppServer.class);

    private final Integer maxConcurrentRequests;

    private final Duration oneRequestProcessingTime;

    private final String uuid;

    private AtomicInteger currentRequests = new AtomicInteger();

    private Lock availabilityLock = new ReentrantLock();

    private Semaphore semaphore;

    public SimpleAppServer(Integer maxConcurrentRequests, Duration oneRequestProcessingTime) {
        this(UUID.randomUUID().toString(), maxConcurrentRequests, oneRequestProcessingTime);
    }

    public SimpleAppServer(String customUuid, Integer maxConcurrentRequests,
                          Duration oneRequestProcessingTime) {
        super(111);

        // Sanity check
        if (Strings.isEmpty(customUuid)) {
            throw new IllegalArgumentException("UUID cannot be `null` or empty!");
        }
        if (maxConcurrentRequests <= 0) {
            throw new IllegalArgumentException(
                    "Maximum allowed concurrent requests must be greater than zero!");
        }
        if (oneRequestProcessingTime.isNegative()) {
            throw new IllegalArgumentException("Processing time for one request must be positive!");
        }

        this.uuid = customUuid;
        this.maxConcurrentRequests = maxConcurrentRequests;
        this.oneRequestProcessingTime = oneRequestProcessingTime;
        this.semaphore = new Semaphore(maxConcurrentRequests);
    }

    @Override
    public String get() {

        availabilityLock.lock();
        semaphore.acquireUninterruptibly();
        currentRequests.incrementAndGet();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                semaphore.release();
                currentRequests.decrementAndGet();
            }
        };
        Timer timer = new Timer(MessageFormat.format("timer_{0}", UUID.randomUUID()));
        timer.schedule(task, oneRequestProcessingTime.toMillis());

        availabilityLock.unlock();
        return uuid;
    }

    @Override
    public Boolean check() {

        availabilityLock.lock();
        semaphore.acquireUninterruptibly();
        semaphore.release();
        availabilityLock.unlock();

        return true;
    }

    @Override
    public Float getCurrentLoad() {
        return (float) currentRequests.get() / (float) maxConcurrentRequests;
    }

    @Override
    public void setAvailability(Boolean availability) {

        if (Boolean.FALSE.equals(availability)) {
            if (!availabilityLock.tryLock()) {
                logger.warn("Availability already set to `true`.");
            }
        } else {
            availabilityLock.unlock();
        }
    }

    @Override
    protected String doJob() throws InterruptedException {

        return "Welcome to server"+1+".";
    }
}
