package impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public abstract class AppProcess {
    protected final int port;
    protected BufferedReader inFromMaster;
    protected PrintWriter outToS2C;
    protected Socket listen2Master;
    protected Socket send2Master;
    String jobStr;

    public AppProcess(int port) {
        this.port = port;
    }


    public void run() {
        try {
            connect();
            while (true) {
                jobStr = inFromMaster.readLine();
                System.out.println("Slave line read: " + jobStr);
                doJob();
                //Inform the master that we just finished a job
                outToS2C.println(jobStr);
                System.out.println("Slave finished! Restarting...");
            }
        } catch (SocketException se) {
            System.out.println("Master disconnected");
        } catch
        (IOException | InterruptedException e) {
            disconnect();
            e.printStackTrace();
        }
    }


    protected void connect() {
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            listen2Master = serverSocket.accept();
            inFromMaster = new BufferedReader(new InputStreamReader(listen2Master.getInputStream()));
            send2Master = new Socket("127.0.0.1", 54321);
            outToS2C = new PrintWriter(send2Master.getOutputStream(), true);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void disconnect() {
        try {
            outToS2C.close();
            inFromMaster.close();
            listen2Master.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected abstract String doJob() throws InterruptedException;

}
