package appengine;

import protocol.AppEngine;

import java.io.PrintWriter;
import java.net.Socket;

public class Engine1 extends Thread implements AppEngine {
    private String input;
    private Socket masterSocket;
    private String outStr = "";
    PrintWriter outToMaster;

    public void run() {

    }

}
