package protocol;

public interface AppEngine {


}
