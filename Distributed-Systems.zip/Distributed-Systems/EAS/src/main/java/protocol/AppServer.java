package protocol;

public interface AppServer {

    String get();

    Boolean check();

    Float getCurrentLoad();

    void setAvailability(Boolean availability);
}
