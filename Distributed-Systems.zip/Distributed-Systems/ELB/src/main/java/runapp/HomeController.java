package runapp;

import impl.BaseLoadBalancer;
import impl.RandomLoadBalancer;
import impl.RoundRobinLoadBalancer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @Value("${elb.rule}")
    private String rule;

    @Autowired
    BaseLoadBalancer baseLoadBalancer;

    @GetMapping("/")
    public String home() {
        return baseLoadBalancer.get();
    }

    @Bean
    public BaseLoadBalancer registerLB() throws Exception {
        if (rule != null && rule.equals("random")) {
            return new RandomLoadBalancer(8l, 5l);
        } else if (rule != null && rule.equals("round")) {
            return new RoundRobinLoadBalancer(8l, 5l);
        }

        throw new Exception("LB rule not defined");
    }
}
