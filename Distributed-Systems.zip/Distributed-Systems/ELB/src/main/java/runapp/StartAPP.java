package runapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartAPP {
    public static void main(String[] args) {
        SpringApplication.run(StartAPP.class, args);
    }
}


