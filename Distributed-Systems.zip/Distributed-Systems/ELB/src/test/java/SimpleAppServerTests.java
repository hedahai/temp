import protocol.AppServer;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

public class SimpleAppServerTests {

    @ParameterizedTest
    @ValueSource(ints = {0, 5, 9, 10, 11, 16, 32})
    public void testAppServerConcurrentRequests(Integer requests) {
        AppServer appServer = Utils.createSimpleAppServer();

        Float maxLoad =
                Math.min(1.0f, (float) requests / (float) Constants.appServerMaxConcurrentRequests);
        Duration processingWaitTime =
                Constants.appServerRequestProcessingTime.multipliedBy(1 + (long) Math
                        .ceil((float) requests / (float) Constants.appServerMaxConcurrentRequests));

        // Create a thread pool to execute multiple concurrent requests to appServer
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();

        for (int i = 0; i < requests; i++) {
            final int iteration = i;
            executor.submit(() -> {
                System.out.println(MessageFormat.format("Iteration {0}, appServer {1}", iteration,
                        appServer.get()));
            });
        }

        // @formatter:off
        Awaitility.await()
                .pollInterval(Duration.ofMillis(500))
                .atMost(Duration.ofSeconds(2))
                .until(() -> Math.abs(maxLoad - appServer.getCurrentLoad()) < Constants.eps);
        // @formatter:on

        System.out.println(MessageFormat.format("Current load: {0}", appServer.getCurrentLoad()));

        // @formatter:off
        Awaitility.await()
                .pollInterval(Duration.ofSeconds(2))
                .atMost(processingWaitTime)
                .until(() -> appServer.getCurrentLoad() < Constants.eps);
        // @formatter:on
    }

    @Test
    public void testAppServerAvailability() {
        AppServer appServer = Utils.createSimpleAppServer();

        System.out.println("Set appServer as unavailable");

        appServer.setAvailability(false);

        System.out.println("Check appServer is unavailable when invoking `check` method");

        CompletableFuture<Boolean> checkFuture = CompletableFuture.supplyAsync(appServer::check);
        assertThrows(TimeoutException.class, () -> checkFuture.get(2, TimeUnit.SECONDS));

        System.out.println("Check appServer is unavailable when invoking `get` method");

        CompletableFuture<String> getFuture = CompletableFuture.supplyAsync(appServer::get);
        assertThrows(TimeoutException.class, () -> getFuture.get(2, TimeUnit.SECONDS));

        System.out.println("Set appServer as available");

        appServer.setAvailability(true);

        System.out.println("All requests to appServer must work and return immediately");

        assertDoesNotThrow(() -> assertEquals(Boolean.TRUE, checkFuture.get()));
        assertDoesNotThrow(() -> assertNotNull(getFuture.get()));
    }
}
