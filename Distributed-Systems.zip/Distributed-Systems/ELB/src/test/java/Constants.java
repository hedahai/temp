import java.time.Duration;

class Constants {

    /**
     * Epsilon.
     */
    static final Float eps = (float) Math.pow(10, -8);

    /**
     * Max concurrent requests that one appServer can handle.
     */
    static final Integer appServerMaxConcurrentRequests = 10;

    /**
     * The artificial processing time for one appServer's request.
     */
    static final Duration appServerRequestProcessingTime = Duration.ofSeconds(5);

    /*
     * Time interval the load balancer will check if the registered appServers are alive or not.
     */
    static final Duration loadBalancerAliveInterval = Duration.ofSeconds(5);

    /**
     * Timeout until a appServer is marked unavailable.
     */
    static final Duration loadBalancerAliveTimeout = Duration.ofSeconds(2);

    /**
     * Idem.
     */
    static final String dummyAppServerName = "dummy_appServer_name";
}
