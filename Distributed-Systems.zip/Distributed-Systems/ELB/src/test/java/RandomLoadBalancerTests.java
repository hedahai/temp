import error.MaxLoadException;
import protocol.LoadBalancer;
import protocol.AppServer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

public class RandomLoadBalancerTests {

    @Test
    public void testRandomOneAppServer() {
        String customUuid = Constants.dummyAppServerName;
        AppServer appServer = Utils.createSimpleAppServer(customUuid);

        LoadBalancer loadBalancer = Utils.createRandomLoadBalancer();
        loadBalancer.registerAppServers(List.of(appServer));

        System.out.println(MessageFormat.format(
                "Send {0} requests to the appServer. All of them must return the same UUID",
                Constants.appServerMaxConcurrentRequests));

        for (int i = 0; i < Constants.appServerMaxConcurrentRequests; i++) {
            assertEquals(customUuid, loadBalancer.get());
        }
    }

    @ParameterizedTest
    @CsvSource({"10,10", "5,25", "1,10", "1,1", "1,0", "10,100", "7,63"})
    public void testRandomMultipleAppServers(Integer appServerCount, Integer requests) {
        List<String> appServerNames = Utils.getDummyAppServerNames(appServerCount);
        LoadBalancer loadBalancer = Utils.createRandomLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream().map(Utils::createSimpleAppServer)
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        System.out.println(
                "Check that requests to load balancer will be forwarded to random appServers");

        Map<String, Integer> responses = new HashMap<>();

        for (int i = 0; i < requests; i++) {
            String uuid = assertDoesNotThrow(() -> loadBalancer.get());
            responses.put(uuid, responses.getOrDefault(uuid, 0) + 1);
        }

        // @formatter:off
        String distribution = appServerNames.stream()
                .map(key -> (float) responses.getOrDefault(key, 0))
                .map(acc -> requests > 0 ? acc / (float) requests : -1.0f)
                .map(rate -> String.format("%.02f", rate))
                .collect(Collectors.joining( ", " ));
        // @formatter:on

        System.out.println(MessageFormat.format("Request distribution: [{0}]", distribution));
    }

    @ParameterizedTest
    @CsvSource({"1,11", "2,25", "5,99", "10,999"})
    public void testRandomMultipleAppServersOverloaded(Integer appServerCount, Integer requests) {
        List<String> appServerNames = Utils.getDummyAppServerNames(appServerCount);
        LoadBalancer loadBalancer = Utils.createRandomLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream().map(Utils::createSimpleAppServer)
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        System.out.println("Check that load balancer will throw an exception once maximum "
                + "capacity is reached on all appServers");

        assertThrows(MaxLoadException.class, () -> {
            for (int i = 0; i < requests; i++) {
                loadBalancer.get();
            }
        });
    }
}
